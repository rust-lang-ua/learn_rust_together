![Rust](./doc/image/Logo2.jpg)

Secondary collection of lists of resources to learn Rust with us. In the collection with have resources which are not finished or there is a reason not recommend it.

### Not finished general-purpose video-courses

( _video_ ) ( _general_ ) ( _not-finished_ )

- [ Rust Videos with Engineer Man](https://www.youtube.com/playlist?list=PLVvjrrRCBy2JSHf9tGxGKJ-bYAN_uDCUL)
- [ Rust Tutorials with Jeff No Zhao](https://www.youtube.com/playlist?list=PLkO5ggdQuRaaeFke7nWS4ajhFVZ1biE7_)
