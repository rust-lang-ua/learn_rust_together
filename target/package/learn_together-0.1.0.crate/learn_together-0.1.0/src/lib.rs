//! # Learn Together
//! Curated collection of lists of useful resources to learn Rust together.
//! # Experiment
//! Experiment

pub fn main()
{
}

#[cfg(test)]
mod tests {
    #[test]
    fn it_works() {
        assert_eq!(2 + 2, 4);
    }
}
